import grails.util.GrailsUtil
import sugamya.User
import sugamya.RoomProfile

class BootStrap {
    def init = { servletContext ->
        switch(GrailsUtil.environment){
        case "development":
            def admin = new User(login:"admin", password:"admin", role:"admin")
            admin.save()
            if(admin.hasErrors()){
                println admin.errors
            }
         
            def phaneesh = new User(login:"phaneesh", password:"123", role:"user")
            phaneesh.save()
            if(phaneesh.hasErrors()){
                println phaneesh.errors
            }
             case "production":
                 def admin = new User(login:"admin", password:"admin", role:"admin")
            admin.save()
            if(admin.hasErrors()){
                println admin.errors
            }
         
            def phaneesh = new User(login:"phaneesh", password:"123", role:"user")
            phaneesh.save()
            if(phaneesh.hasErrors()){
                println phaneesh.errors
            }
}
    
    }
}