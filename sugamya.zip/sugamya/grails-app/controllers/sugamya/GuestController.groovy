package sugamya

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class GuestController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond Guest.list(params), model:[guestInstanceCount: Guest.count()]
    }

    def show(Guest guestInstance) {
        respond guestInstance
    }

    def create() {
               
        respond new Guest(params)
        
    }
   

    @Transactional
    def save(Guest guestInstance) {
        if (guestInstance == null) {
            notFound()
            return
        }

        if (guestInstance.hasErrors()) {
            respond guestInstance.errors, view:'create'
            return
        }

        guestInstance.save flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.created.message', args: [message(code: 'guestInstance.label', default: 'Guest'), guestInstance.id])
                redirect guestInstance
            }
            '*' { respond guestInstance, [status: CREATED] }
        }
    }

    def edit(Guest guestInstance) {
        respond guestInstance
    }

    @Transactional
    def update(Guest guestInstance) {
        if (guestInstance == null) {
            notFound()
            return
        }

        if (guestInstance.hasErrors()) {
            respond guestInstance.errors, view:'edit'
            return
        }

        guestInstance.save flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'Guest.label', default: 'Guest'), guestInstance.id])
                redirect guestInstance
            }
            '*'{ respond guestInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(Guest guestInstance) {

        if (guestInstance == null) {
            notFound()
            return
        }

        guestInstance.delete flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Guest.label', default: 'Guest'), guestInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'guestInstance.label', default: 'Guest'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
//    def select() {
//        def booking = Booking.get(params.id)
//        [booking: booking]
//    }

    def insert(){
//        def booking = Booking.get(params.id)
//        [booking: booking]
//        
//        redirect action:"create"
    }
}
