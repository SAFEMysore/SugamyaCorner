package sugamya



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class RoomProfileController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond RoomProfile.list(params), model:[roomProfileInstanceCount: RoomProfile.count()]
    }

    def show(RoomProfile roomProfileInstance) {
        respond roomProfileInstance
    }

    def create() {
        respond new RoomProfile(params)
    }

    @Transactional
    def save(RoomProfile roomProfileInstance) {
        if (roomProfileInstance == null) {
            notFound()
            return
        }

        if (roomProfileInstance.hasErrors()) {
            respond roomProfileInstance.errors, view:'create'
            return
        }

        roomProfileInstance.save flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.created.message', args: [message(code: 'roomProfileInstance.label', default: 'RoomProfile'), roomProfileInstance.id])
                redirect roomProfileInstance
            }
            '*' { respond roomProfileInstance, [status: CREATED] }
        }
    }

    def edit(RoomProfile roomProfileInstance) {
        respond roomProfileInstance
    }

    @Transactional
    def update(RoomProfile roomProfileInstance) {
        if (roomProfileInstance == null) {
            notFound()
            return
        }

        if (roomProfileInstance.hasErrors()) {
            respond roomProfileInstance.errors, view:'edit'
            return
        }

        roomProfileInstance.save flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'RoomProfile.label', default: 'RoomProfile'), roomProfileInstance.id])
                redirect roomProfileInstance
            }
            '*'{ respond roomProfileInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(RoomProfile roomProfileInstance) {

        if (roomProfileInstance == null) {
            notFound()
            return
        }

        roomProfileInstance.delete flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'RoomProfile.label', default: 'RoomProfile'), roomProfileInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'roomProfileInstance.label', default: 'RoomProfile'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
