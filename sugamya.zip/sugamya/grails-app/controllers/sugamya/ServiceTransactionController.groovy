package sugamya



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class ServiceTransactionController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond ServiceTransaction.list(params), model:[serviceTransactionInstanceCount: ServiceTransaction.count()]
    }

    def show(ServiceTransaction serviceTransactionInstance) {
        respond serviceTransactionInstance
    }

    def create() {
        respond new ServiceTransaction(params)
    }

    @Transactional
    def save(ServiceTransaction serviceTransactionInstance) {
        if (serviceTransactionInstance == null) {
            notFound()
            return
        }

        if (serviceTransactionInstance.hasErrors()) {
            respond serviceTransactionInstance.errors, view:'create'
            return
        }

        serviceTransactionInstance.save flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.created.message', args: [message(code: 'serviceTransactionInstance.label', default: 'ServiceTransaction'), serviceTransactionInstance.id])
                redirect serviceTransactionInstance
            }
            '*' { respond serviceTransactionInstance, [status: CREATED] }
        }
    }

    def edit(ServiceTransaction serviceTransactionInstance) {
        respond serviceTransactionInstance
    }

    @Transactional
    def update(ServiceTransaction serviceTransactionInstance) {
        if (serviceTransactionInstance == null) {
            notFound()
            return
        }

        if (serviceTransactionInstance.hasErrors()) {
            respond serviceTransactionInstance.errors, view:'edit'
            return
        }

        serviceTransactionInstance.save flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'ServiceTransaction.label', default: 'ServiceTransaction'), serviceTransactionInstance.id])
                redirect serviceTransactionInstance
            }
            '*'{ respond serviceTransactionInstance, [status: OK] }
        }
    }

    @Transactional
    def delete(ServiceTransaction serviceTransactionInstance) {

        if (serviceTransactionInstance == null) {
            notFound()
            return
        }

        serviceTransactionInstance.delete flush:true

        request.withFormat {
            form {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'ServiceTransaction.label', default: 'ServiceTransaction'), serviceTransactionInstance.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'serviceTransactionInstance.label', default: 'ServiceTransaction'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
