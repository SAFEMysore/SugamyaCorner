package sugamya

class Address {

    Integer id
    String lane1
    String lane2
    String street
    String city
    String pincode
    String state
    String country
    
    static constraints = {
        id()
        lane1()
        lane2()
        street()
        city()
        pincode()
        state()
        country()
    }
    
   
    static belongsTo=[guest:Guest]
   
}
