package sugamya

//import java.util.Formatter.DateTime

class Bill {
    
    
   Integer id
   String guestName
  Double bookingAmount  
  Double damageAmount
  Double foodAmount
  Double miscellaneousServicesAmount
  Date checkOutDate
  
   
    static constraints = {
       guestName()
        id()
        checkOutDate()
        bookingAmount()
  
        damageAmount(blank:true, nullable:true)
        foodAmount(blank:true, nullable:true)
        miscellaneousServicesAmount(blank:true, nullable:true)
    }
    

        static belongsTo = [booking:Booking,roomProfile:RoomProfile]
         static hasMany=[payment:Payment]



}
//    static belongsTo=[booking:Booking,guest:Guest,roomProfile:RoomProfile,payment:Payment,serviceTransaction:ServiceTransaction]

