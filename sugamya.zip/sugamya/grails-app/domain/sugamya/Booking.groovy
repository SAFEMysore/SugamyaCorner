    package sugamya

//import java.sql.Time

//import java.util.Formatter.DateTime

class Booking {
    
    Integer id
    String bookingName
    Date bookingDate
    Date checkInDate
    Date checkOutDate
    Integer numberOfRooms
    Integer numberOfAdults
    Integer numberOfChildren
    Integer numberOfNights
    String mobileNumber
    String emailId
    String bookingMode="Online"
    String bookingPlan="CP"
    Double advanceAmount
    String place
   

    static constraints = {
        
        id()
        bookingName()
        bookingDate()
        numberOfAdults()
        numberOfRooms()
        numberOfChildren()
        numberOfNights()
        checkInDate()
        mobileNumber()
        emailId(blank:true, nullable:true)
        checkOutDate()
        bookingMode(inList:["Online","Direct","Corporate","Complimentary"])
        bookingPlan(inList:["None","CP","MAP"])
        advanceAmount(blank:true,nullable:true)
        place(blank:true,nullable:true)

    }
    
    static hasMany = [guest:Guest,bill:Bill]
    
      static searchable = true
}
