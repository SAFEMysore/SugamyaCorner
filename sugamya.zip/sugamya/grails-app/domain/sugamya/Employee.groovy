package sugamya

class Employee {
    
       Integer id
       String employeeName
       String description
       String mobileNumber
       String emailId
       String gender="M"
      
    static constraints = {
        id()
        employeeName()
        description()
        mobileNumber()
        emailId()
        gender(inList:["M", "F"])
//        address(blank:true)
        
    }
    
//    static b = [address:Address]
    
//        static belongsTo = [user:User,address:Address]

}
