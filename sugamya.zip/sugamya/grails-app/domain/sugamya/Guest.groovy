package sugamya


class Guest {
    Integer id
    String bookingName
    String guestName
//    String typeOfId="DL"
    String identityCardNumber
    String nationality
    String mobileNumber
    String emailId
    Double bookingAmount
   
     Date checkInDate
     
    static constraints = {
        id()
        checkInDate()
        bookingName(blank:true, nullable:true)
        guestName(blank:true, nullable:true)
//        typeOfId(inList:["DL","Aadhar Card","Voter Id","Passport","Others"])
        identityCardNumber()
        nationality()
        mobileNumber()
        emailId()
        bookingAmount()
    }
//      static mapping = {
//    autoTimestamp true
//    }    
    
    static belongsTo = [booking:Booking,roomProfile:RoomProfile]
    static hasMany=[address:Address]
   
//    static searchable = true 
}
    

      
