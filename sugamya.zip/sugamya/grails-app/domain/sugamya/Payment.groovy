package sugamya

class Payment {

    Integer id
    String modeOfPayment="m-swipe"
    Date paymentDate
    Double discount
    Double amountPaid
    Double remainingAmount
    
       
    static constraints = {
        id()
        modeOfPayment(inList:["m-swipe","cash","Online"])
        paymentDate()
        discount()
        amountPaid()
        remainingAmount()
    }
    
    static belongsTo = [bill:Bill]
    
}
