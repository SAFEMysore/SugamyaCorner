package sugamya

class RoomProfile {
    
    Integer id
    String roomName
    String roomType
    String floor
    Double basePrice
    
    static constraints = {
        
        id()
        roomType(inList:["Standard","Deluxe Room with Balcony","Family-Suite","Superior Triple Room"])
        roomName(inList:["R1","R2","R3","R4","R5","R6","R7","R8","R9","R10","S2","S3","S4"])
        floor(inList:["I","II"])
        basePrice()
    }
    
    static hasMany = [guest:Guest]


}
