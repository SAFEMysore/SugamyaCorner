package sugamya

class ServiceCategory {
    Integer id
    String typeOfServiceProvided

    static constraints = {
        id()
        typeOfServiceProvided(inList:["Standard", "Deluxe Room with Balcony","Superior Triple Room","Family-Suite"])
    }
    
//    static hasMany =[serviceTransaction:ServiceTransaction]
}
