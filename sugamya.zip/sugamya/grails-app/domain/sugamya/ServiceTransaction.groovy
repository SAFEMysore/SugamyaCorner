package sugamya

class ServiceTransaction {

    Integer id
    Double serviceCost
    static constraints = {
        id()
        serviceCost()
    }
    
//    static hasMany=[serviceTransaction:ServiceTransaction]
            

}
