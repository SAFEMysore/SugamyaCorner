package sugamya

class User {

        Integer id
        String login
        String password
        String role="user"
    static constraints = {
        id()
        login(blank:false, nullable:false, unique:true)
        password(blank:false, password:true)
        role(inList:["admin", "user"])

    }
     static transients = ['admin']
boolean isAdmin(){
    return role == "admin"
}
//        static hasMany = [employee:Employee]

}
