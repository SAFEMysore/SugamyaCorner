package sugamya

import grails.test.mixin.Mock
import spock.lang.Specification

@Mock(AdminFilters)
class AdminFiltersSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
